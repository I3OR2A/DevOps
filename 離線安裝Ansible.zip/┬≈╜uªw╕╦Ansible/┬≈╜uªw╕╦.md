### 离线安装AWX15.0.1

安裝 ansible awx 版本

https://hub.docker.com/r/ansible/awx

- 环境：
  - centos 7.6 （最小化安装）
    - https://app.vagrantup.com/centos/boxes/7
  - 关闭selinux
  - 

```bash
vagrant init centos/7
```

修改 Vagrantfile

```bash

  # 使用 DHCP 的設定作為 default route
  config.vm.network "public_network",
  use_dhcp_assigned_default_route: true
  
  config.vm.provider "virtualbox" do |vb|
  #   # Display the VirtualBox GUI when booting the machine
    vb.gui = true
  end
```

离线安装 gcc

下载所需要的包,下载地址[rpmfiind](http://rpmfind.net/linux/rpm2html/search.php)或[pkgs.org](https://centos.pkgs.org/7/centos-x86_64/),或通過以下指令於聯網機器上進行下載

```bash
yum install --downloadonly --downloaddir=/root/software/gcc gcc
```

所需包![image-20210418161643344](D:\Work\筆記\Ansible使用手冊\image-20210418161643344.png)

上传至服务器任意目录

在上传目录执行安装

```bash
rpm -Uvh --force ./*.rpm
rpm -ivh ./*.rpm
```

测试

```bash
gcc -v
```

离线安装 python3.7.0

下载python安装包以及依赖的包

下载地址：[Python-3.7.0](http://www.python.org/ftp/python/3.7.0/Python-3.7.0.tar.xz)

```bash
curl -L https://www.python.org/ftp/python/3.7.0/Python-3.7.0.tgz -o /root/software/python37/Python-3.7.0.tgz
```

依赖包下载地址：[rpmfind](http://rpmfind.net/linux/rpm2html/search.php)或[pkgs.org](https://centos.pkgs.org/7/centos-x86_64/)

```bash
yum install --downloadonly --downloaddir=/root/software/python37 zlib-devel bzip2-devel openssl-devel ncurses-devel  epel-release gcc gcc-c++ xz-devel readline-devel gdbm-devel sqlite-devel tk-devel db4-devel libpcap-devel libffi-devel
```

所需包![image-20210418163319728](D:\Work\筆記\Ansible使用手冊\image-20210418163319728.png)

安装依赖

```
rpm -Uvh --force ./*.rpm
rpm -ivh ./*.rpm
```

解压python安装包

```
tar -zxvf Python-3.7.0.tgz
```

编译安装

```
mkdir /usr/local/python3 # 创建编译安装目录
cd Python-3.7.0　　　　　　# 进入python的解压目录
./configure --prefix=/usr/local/python3 
make && make install　　　# 编译$安装
```

创建软连接

```
ln -s /usr/local/python3/bin/python3 /usr/local/bin/python3
ln -s /usr/local/python3/bin/pip3 /usr/local/bin/pip3
```

更新pip

```
pip3 install --upgrade --find-links=../ pip
```

验证是否安装成功

```
python3 -V
pip3 -V
```

离线安装ansible2.9

下载ansible2.9安装包以及依赖的包

```
#部分rpm包通过有网络环境的测试主机下载，如：
#若提示已安装需先卸载后进行下载
yum install --downloadonly --downloaddir=/root/software/ansible sshpass
yum install --downloadonly --downloaddir=/root/software/ansible ansible
yum install --downloadonly --downloaddir=/root/software/ansible python-httplib2
```

若出現以下問題

```
No package ansible available.
```

原理：Ansible是属于Extra Packages for Enterprise Linux (EPEL)库的一部分，因此要先安装EPEL

```
yum install epel-release
yum repolist
yum install --downloadonly --downloaddir=/root/software/ansible ansible
```

所需包

![image-20210418164628714](D:\Work\筆記\Ansible使用手冊\image-20210418164628714.png)

上传至服务器任意目录

安装依赖包及ansible

```
rpm -Uvh --force ./*.rpm
rpm -ivh ./*.rpm
```

验证

```
ansible --version
```

离线安装docker、docker-compose

下载所需安装包

```
yum install --downloadonly --downloaddir=/root/software/docker docker
yum install --downloadonly --downloaddir=/root/software/docker docker-compose
```

所需包

![image-20210418165110633](D:\Work\筆記\Ansible使用手冊\image-20210418165110633.png)![image-20210418165147914](D:\Work\筆記\Ansible使用手冊\image-20210418165147914.png)

上传至服务器

安装依赖

```
rpm -Uvh --force ./*.rpm
rpm -ivh ./*.rpm
```

启动docker

```
systemctl start docker
systemctl enable docker
```

验证

```
systemctl status docker
```

离线安装bash-completion命令补全工具

下载

```
yum install --downloadonly --downloaddir=/root/software/docker bash-completion
```

上传至服务器

加载bash-completion

```
source /etc/profile.d/bash_completion.sh
```

离线安装docker-compose

下载docker-compose

```
curl -L "https://github.com/docker/compose/releases/download/1.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
```

将文件上传至指定服务器/usr/bin目录下

赋予可执行权限

```
chmod a+x /usr/local/bin/docker-compose
```

测试

```
docker-compose --version
```

离线安装python docker-compose

离线包下载

```
pip3 download -d /root/software/python-docker docker
pip3 download -d /root/software/python-docker-compose docker-compose
```

所需包

上传至服务器

安装

```
pip3 install --no-index --find-links=/root/software/python-docker docker
pip3 install --no-index --find-links=/root/software/python-docker-compose docker-compose
```

验证

```
pip3 list
```

AWX离线安装

下载ansible/awx镜像

```
#联网主机下进行
docker pull ansible/awx:17.1.0
docker images
docker save 599918776cf2 -o /root/software/ansible/ansible-awx-docker-17.1.0.tar
```

离线导入ansible/awx镜像

```
#上传awx.tar到任意目录
docker load --input /root/software/ansible/ansible-awx-docker-17.1.0.tar
```

查看并重命名

```
docker images
#导入时默认名称为<none>
#为镜像指定tag
docker tag 599918776cf2 ansible/awx:17.1.0
```

上传awx安装包到任意目录并解压，下载地址：[ansible/awx](https://github.com/ansible/awx/releases)

```
curl -L https://github.com/ansible/awx/archive/refs/tags/17.1.0.tar.gz -o /root/software/ansible/ansible-awx-17.1.0.tar.gz
```

```
[root@localhost ansible]# pwd
/root/software/ansible
[root@localhost ansible]# tar zxf ansible-awx-17.1.0.tar.gz
```

修改配置

```
[root@localhost installer]# pwd
/root/software/ansible/awx-17.1.0/installer
[root@localhost installer]# ls
build.yml  install.yml  inventory  roles
[root@localhost installer]# vi inventory 

localhost ansible_connection=local ansible_python_interpreter="/usr/bin/env python3"
#若安装主机非本地则将localhost ansible_connection=local 修改为目标主机ip或域名
[all:vars]

# Remove these lines if you want to run a local image build
# Otherwise the setup playbook will install the official Ansible images. Versions may
# be selected based on: latest, 1, 1.0, 1.0.0, 1.0.0.123
# by default the base will be used to search for ansible/awx
dockerhub_base=ansible
awx_task_hostname=awx  
awx_web_hostname=awxweb 
postgres_data_dir="~/.awx/pgdocker" 
host_port=80
host_port_ssl=443
#ssl_certificate=
# Optional key file
#ssl_certificate_key=
docker_compose_dir="~/.awx/awxcompose"

# Required for Openshift when building the image on your own
# Optional for Openshift if using Dockerhub or another prebuilt registry
# Required for Docker Compose Install if building the image on your own
# Optional for Docker Compose Install if using Dockerhub or another prebuilt registry
# Define if you want the image pushed to a registry. The container definition will also use these images
# docker_registry=172.30.1.1:5000
# docker_registry_repository=awx
# docker_registry_username=developer


# Set pg_hostname if you have an external postgres server, otherwise
# a new postgres service will be created
# pg_hostname=postgresql #使用已有pg数据库时启用该项
pg_username=awx  #pg数据库用户名
# pg_password should be random 10 character alphanumeric string, when postgresql is running on kubernetes
# NB: it's a limitation of the "official" postgres helm chart
pg_password=awxpass  #密码
pg_database=awx   #库名
pg_port=5432  #端口号
#pg_sslmode=require

# If requiring SSL communication (e.g. pg_sslmode='verify-full') with Postgres
# and using a self-signed certificate or a certificate signed by a custom CA
# set pg_root_ca_file to a file containing the self-signed certificate or the
# root CA certificate chain.
# pg_root_ca_file='example_root_ca.crt'

# The following variable is only required when using the provided
# containerized postgres deployment on OpenShift
# pg_admin_password=postgrespass

# Use a local distribution build container image for building the AWX package
# This is helpful if you don't want to bother installing the build-time dependencies as
# it is taken care of already.
# NOTE: IMPORTANT: If you are running a mininshift install, using this container might not work
#                  if you are using certain drivers like KVM where the source tree can't be mapped
#                  into the build container.
#                  Thus this setting must be set to False which will trigger a local build. To view the
#                  typical dependencies that you might need to install see:
#                  installer/image_build/files/Dockerfile.sdist
# use_container_for_build=true

# This will create or update a default admin (superuser) account in AWX, if not provided
# then these default values are used
admin_user=admin  #awx管理员用户
admin_password=password  #awx管理员密码

# Whether or not to create preload data for demonstration purposes
create_preload_data=True

# AWX Secret key
# It's *very* important that this stay the same between upgrades or you will lose the ability to decrypt
# your credentials
secret_key=awxsecret 

# By default a broadcast websocket secret will be generated.
# If you would like to *rerun the playbook*, you need to set a unique password.
# Otherwise it would generate a new one every playbook run.
# broadcast_websocket_secret=

# Build AWX with official logos
# Requires cloning awx-logos repo as a sibling of this project.
# Review the trademark guidelines at https://github.com/ansible/awx-logos/blob/master/TRADEMARKS.md
# awx_official=false

# Proxy   #网络代理相关配置，默认不启用
#http_proxy=http://proxy:3128
#https_proxy=http://proxy:3128
#no_proxy=mycorp.org

# Container networking configuration
# Set the awx_task and awx_web containers' search domain(s)
#awx_container_search_domains=example.com,ansible.com
# Alternate DNS servers
#awx_alternate_dns_servers="10.1.2.3,10.2.3.4"

# AWX project data folder. If you need access to the location where AWX stores the projects
# it manages from the docker host, you can set this to turn it into a volume for the container.
project_data_dir=/awx/projects  #ansibe项目存放在本地文件路径
# AWX custom virtual environment folder. Only usable for local install.
#custom_venv_dir=/opt/my-envs/

# CA Trust directory. If you need to provide custom CA certificates, supplying
# this variable causes this directory on the host to be bind mounted over
# /etc/pki/ca-trust in the awx_task and awx_web containers.
# If you are deploying on openshift or kubernetes, set the variable to /etc/pki/ca-trust instead,
# as the awx_web and awx_task containers will not run the `update-ca-trust` command.
#ca_trust_dir=/etc/pki/ca-trust/source/anchors

# Include /etc/nginx/awx_extra.conf
# Note the use of glob pattern for nginx
# which makes include "optional" - i.e. not fail
# if file is absent
#extra_nginx_include="/etc/nginx/awx_extra[.]conf"

# Docker compose explicit subnet. Set to avoid overlapping your existing LAN networks.
#docker_compose_subnet="172.17.0.1/16"
#
# Allow for different docker logging drivers
# By Default; the logger will be json-file, however you can override
# that by uncommenting the docker_logger below.
# Be aware that journald may rate limit your log messages if you choose it.
# See: https://docs.docker.com/config/containers/logging/configure/
# docker_logger=journald
#

# Add extra hosts to docker compose file. This might be necessary to
# sneak in servernames. For example for DMZ self-signed CA certificates.
# Equivialent to using the --add-host parameter with "docker run".
#docker_compose_extra_hosts="otherserver.local:192.168.0.1,ldap-server.local:192.168.0.2"
```

执行安装脚本

```
ansible-playbook -i inventory  install.yml
```

執行出現錯誤

```
TASK [local_docker : Create Docker Compose Configuration] *****************************************************************************************
failed: [localhost] (item={u'mode': u'0600', u'file': u'environment.sh'}) => {"ansible_loop_var": "item", "changed": false, "checksum": "18957af76126a0769a3d66e4e5a62ff17144eed2", "item": {"file": "environment.sh", "mode": "0600"}, "msg": "Aborting, target uses selinux but python bindings (libselinux-python) aren't installed!"}
failed: [localhost] (item={u'mode': u'0600', u'file': u'credentials.py'}) => {"ansible_loop_var": "item", "changed": false, "checksum": "072f5bd1b57ff7f897863f407b143996f97799fd", "item": {"file": "credentials.py", "mode": "0600"}, "msg": "Aborting, target uses selinux but python bindings (libselinux-python) aren't installed!"}
failed: [localhost] (item={u'mode': u'0600', u'file': u'docker-compose.yml'}) => {"ansible_loop_var": "item", "changed": false, "checksum": "fd4c2412e218a9c35de7bd5ccbd14e1836be3841", "item": {"file": "docker-compose.yml", "mode": "0600"}, "msg": "Aborting, target uses selinux but python bindings (libselinux-python) aren't installed!"}
failed: [localhost] (item={u'mode': u'0600', u'file': u'nginx.conf'}) => {"ansible_loop_var": "item", "changed": false, "checksum": "7433a2df79a34332d52f4a7b969614d1cec43a9b", "item": {"file": "nginx.conf", "mode": "0600"}, "msg": "Aborting, target uses selinux but python bindings (libselinux-python) aren't installed!"}
failed: [localhost] (item={u'mode': u'0664', u'file': u'redis.conf'}) => {"ansible_loop_var": "item", "changed": false, "checksum": "4fe3f9421d102ffe15827f7a685fc9c8d5a20b78", "item": {"file": "redis.conf", "mode": "0664"}, "msg": "Aborting, target uses selinux but python bindings (libselinux-python) aren't installed!"}
```

libselinux-python 离线安装

下载

```
yum install --downloadonly --downloaddir=/root/software/extra libselinux-python
```

上传至服务器

安裝依賴

```
rpm -Uvh --force ./*.rpm
rpm -ivh ./*.rpm
```

安装完成以后查看下selinux是否关闭

```
vi  /etc/selinux/config
 
# 修改一下内容：
SELINUX=disabled
 
# 然后重启服务器，如果已经修改了，就不需要重启了，再次执行ansible去检查是否可用。
```

验证

输入 http://172.22.98.54 即可登录ansible AWX

![image-20201102140811709](D:\Work\筆記\Ansible使用手冊\1241092-20201102150844893-341805589.png)

參考資料

[第二十二章、軟體安裝 RPM, SRPM 與 YUM](http://linux.vbird.org/linux_basic/0520rpm_and_srpm.php)

[CentOS7 安装Ansible - No package ansible available](https://my.oschina.net/wangchongya/blog/752027)

[centos離線安裝python3/pip3和項目所需模塊](https://www.twblogs.net/a/5c41efc0bd9eee35b21e9444)

[ansible报错"msg": "Aborting, target uses selinux but python bindings (libselinux-python) aren't instal](https://blog.csdn.net/pufaqi/article/details/82527320)